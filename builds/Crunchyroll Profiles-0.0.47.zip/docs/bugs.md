## Summary
Explains some current bugs and hopefully with instructions on how to avoid them or fix them.

<p>
    If you run into a bug please open up an issue or create a pull request if you know how to fix it.
</p>

## Bugs
* N/A

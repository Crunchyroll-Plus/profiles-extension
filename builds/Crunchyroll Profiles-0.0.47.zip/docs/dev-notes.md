## Summary
Developer notes are notes from either me (the owner) or other contributors explaining something or other information that could potentially be helpful.

## Notes
* N/A

/* 
    This script is for collecting urls since they change frequently.
*/

class Collection {
    constructor(type) {
        this.items = [];
        this.forEach = (callback) => this.items.forEach(callback);
        this.type = type;

        this.push = this.items.push
        this.pop = this.items.pop

        this.update = function(callback) {
            if(this.type === "css") {
                let xml = new XMLHttpRequest();
                xml.open("GET", "https://www.crunchyroll.com/");
                xml.send();

                xml.onload = () => {
                    let text = xml.responseText;

                    let rtlLinks = text.split("const rtlLinks = [")[1].split("]")[0];
                    let ltrLinks = text.split("const ltrLinks = [")[1].split("]")[0]; 

                    this.meta = { isRTL: false }

                    if(locale.language.includes("ar")) {
                        this.meta.isRTL = true
                    }

                    if(this.meta.isRTL)
                        this.items = rtlLinks.replaceAll("\"", "").replaceAll("'", "").replaceAll("`", "").split(",");
                    else
                        this.items = ltrLinks.replaceAll("\"", "").replaceAll("'", "").replaceAll("`", "").split(",");

                    callback(this.items);
                }
            }
        }
        this.meta = {};
    }
}

var collection = {
    css: new Collection("css"),
}